# pendaftaran
Aplikasi Pendaftaran Siswa Baru - Youtube #EDT

https://www.youtube.com/watch?v=RtTqVmfNb-Y&list=PLusV1iDWr_sB3MEXgXOhW9BOwTD_cZxfp

http://e-development.tech/

Menggunakan :
- Template SB-Admin 2
- Bootstrap 4
- PHP 7 NATIVE
- MySQL
- Database di folder "db/pendaftaran_siswa.sql"

Pengguna :
- User : Admin, Siswa

Lingkup Aplikasi :
- Registrasi Siswa
- Dashboard Siswa dan Admin
- Edit Profil Siswa
- Login Sistem
- Rekap Data Pendaftar
- Cetak PDF
